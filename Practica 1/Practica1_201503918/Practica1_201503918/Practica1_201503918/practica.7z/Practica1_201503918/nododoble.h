#ifndef NODODOBLE
#define NODODOBLE

template <class T>;
struct NodoDoble
{
    T dato;
    NodoDoble(T dato_):dato(dato_){}
    NodoDoble *siguiente;
    NodoDoble *anterior;
};

#endif // NODODOBLE

