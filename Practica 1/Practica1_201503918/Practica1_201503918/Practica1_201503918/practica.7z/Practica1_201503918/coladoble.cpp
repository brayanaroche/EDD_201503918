//#include "coladoble.h"
//#include "nodocoladoble.h"
//#include <QDebug>

//using namespace std;

//void inicializar(ColaDoble *cola)
//{
//    cola->fin = NULL;
//    cola->ini = NULL;;
//    cola->tam = 0;
//}

//int Queue(ColaDoble *cola, QString tipo, int pasajeros,int desabordaje, int mantenimiento)
//{
//    NodoColaDoble *nuevoNodo = NULL;
//    //reservamos la memoria para el nuevo nodo
//    nuevoNodo = (NodoColaDoble*)malloc(sizeof(NodoColaDoble));
//    //Asignamos los valores del nuevo nodo
//    nuevoNodo->tipoAvion = tipo;
//    nuevoNodo->pasajerosAvion = pasajeros;
//    nuevoNodo->desabordajeAvion = desabordaje;
//    nuevoNodo->mantenimientoAvion = mantenimiento;
//    //Evaluando el primer caso en que la cola no tiene elementos ingresados
//    if(cola->ini == NULL)
//    {
//        nuevoNodo->siguiente = cola->fin;
//        nuevoNodo->anterior = cola->ini;
//        cola->ini = nuevoNodo;
//        cola->fin = nuevoNodo;
//        cola->tam++;
//    }//Fin
//    //si ya hay un elemento en la lista
//    else
//    {
//        nuevoNodo->siguiente = NULL;
//        nuevoNodo->anterior = cola->ini;
//        cola->fin->siguiente = nuevoNodo;
//        cola->fin = nuevoNodo;
//        cola->tam++;
//    }
//    return 0;
//}

//void mostrarColaDoble(ColaDoble *cola)
//{
//    NodoColaDoble *nodoActual;
//    nodoActual = cola->ini;
//    printf("<><><><><><><>Los Valores Son:<><><><><><><><><>\n");
//    while(nodoActual!=NULL)
//    {
//        //cout << nodoActual->tipoAvion << "\n" << endl;
//        //qDebug() << nodoActual->tipoAvion;
//        //qInfo() << nodoActual->tipoAvion;
//        nodoActual = nodoActual->siguiente;
//    }
//    //qInfo() << nodoActual->tipoAvion;
//    //qDebug() << nodoActual->tipoAvion;
//    //cout << nodoActual->tipoAvion << "\n" << endl;
//    printf("<><><><><><><><><><><><><><><><><><><><><><><><>\n");
//}
