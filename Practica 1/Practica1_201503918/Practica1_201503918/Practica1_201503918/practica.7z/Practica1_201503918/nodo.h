#ifndef NODO
#define NODO

#endif // NODO

