#ifndef COLADOBLE_H
#define COLADOBLE_H
#include "nododoble.h"
#include <QString>
#include <QDebug>

//using namespace std;
template <class T>
struct ColaDoble
{
    NodoDoble *ini;
    NodoDoble *fin;
    int tam;

    void inicializar()
    {
        ini = NULL;
        fin = NULL;
        tam = 0;
    }

    void insertarColaDoble(T dato)
    {
        NodoDoble *nuevoNodo = NULL;
        nuevoNodo = new Nodo(dato);
        nuevoNodo->dato = dato;
        if(ini == NULL)
        {
            //ini = nuevoNodo;
            nuevoNodo->siguiente = fin;
            nuevoNodo->anterior = ini;
            ini = nuevoNodo;
            fin = nuevoNodo;
            tam++;
            //        nuevoNodo->siguiente = cola->fin;
            //        nuevoNodo->anterior = cola->ini;
            //        cola->ini = nuevoNodo;
            //        cola->fin = nuevoNodo;
            //        cola->tam++;
        }
        else
        {
            nuevoNodo->siguiente = NULL;
            nuevoNodo->anterior = ini;
            fin->siguiente = nuevoNodo;
            fin = nuevoNodo;
            tam++;
            //        nuevoNodo->anterior = cola->ini;
            //        cola->fin->siguiente = nuevoNodo;
            //        cola->fin = nuevoNodo;
            //        cola->tam++;
        }
    }

    void mostrarColaDoble()
    {
        NodoDoble *nodoActual;
        nodoActual = ini;
        qDebug() << "<><><><><><><>Los Valores Son:<><><><><><><><><>\n";
        while(nodoActual != NULL)
        {
            qDebug() << nodoActual->dato;
            nodoActual = nodoActual->siguiente;
        }
        //    printf("<><><><><><><>Los Valores Son:<><><><><><><><><>\n");
        //    while(nodoActual!=NULL)
        //    {
        //        //cout << nodoActual->tipoAvion << "\n" << endl;
        //        //qDebug() << nodoActual->tipoAvion;
        //        //qInfo() << nodoActual->tipoAvion;
        //        nodoActual = nodoActual->siguiente;
        //    }
        //    //qInfo() << nodoActual->tipoAvion;
        //    //qDebug() << nodoActual->tipoAvion;
        //    //cout << nodoActual->tipoAvion << "\n" << endl;
        //    printf("<><><><><><><><><><><><><><><><><><><><><><><><>\n");
    }
};

/*
 * Metodos y funciones para la cola doblemente enlazada


void inicializar(ColaDoble *cola);
int Queue(ColaDoble *cola, QString tipoAvion, int pasajerosAvion, int desabordajeAvion, int mantenimientoAvion);
void mostrarColaDoble(ColaDoble *cola);
int Dequeue(ColaDoble *cola,QString tipoAvion, int pasajerosAvion, int desabordajeAvion, int mantenimientoAvion);
*/
#endif // COLADOBLE_H
