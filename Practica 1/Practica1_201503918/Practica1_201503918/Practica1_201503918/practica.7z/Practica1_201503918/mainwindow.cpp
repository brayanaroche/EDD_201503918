#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "coladoble.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    ColaDoble *cola_doble = new ColaDoble();
    cola_doble->insertarColaDoble(2);
    cola_doble->insertarColaDoble(8);
    cola_doble->mostrarColaDoble();
//    ColaDoble *coladoble;
//    coladoble = (ColaDoble*)malloc(sizeof(coladoble));

//    inicializar(coladoble);
//    Queue(coladoble,"Grande",50,3,2);
//    Queue(coladoble,"Pequeño",30,2,1);
//    Queue(coladoble,"Mediano",70,3,2);
//    Queue(coladoble,"Pequeño",15,2,1);
//    Queue(coladoble,"Grande",40,3,2);
//    Queue(coladoble,"Pequeño",30,1,1);
//    Queue(coladoble,"Grande",50,3,2);
//    Queue(coladoble,"Pequeño",20,2,1);
    //mostrarColaDoble(coladoble);
}
