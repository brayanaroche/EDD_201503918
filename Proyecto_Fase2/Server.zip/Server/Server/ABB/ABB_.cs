﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Globalization;

namespace Server.ABB
{
    public class ABB_
    {
        /*
         * root = raiz o nodo padre
         * highAltitud = Altura
         * childsNode = nodos Hijos
         * branches = ramas
         * level = nivel
         */
        public ABBNode root;

        /*
         * Consultas para ver los mejores jugadores
         */
        
        /*
         * Constructor ABB
         */
        public ABB_()
        {
            root = null;
        }

        /*
         * Insertar ABB
         */
        public void insertABB(string nickName_, string password_, string email_, int conectado_, ListaDoble lstJuego_)
        {
            ABBNode newNode = new ABBNode(nickName_, password_, email_, conectado_, lstJuego_);
            if (root == null)
            {
                root = newNode;
            }
            else
            {
                insertABB(root, nickName_, password_, email_, conectado_, lstJuego_);
            }
        }

        private void insertABB(ABBNode actualRaiz, string nickName_, string password_, string email_, int conectado_, ListaDoble lstJuego_)
        {
            /*
             * Validamos cual es mayor para ver si va a corresponder ser hijo der o hijo izq
             * 1.Lado izquierdo
             * 2.Lado derecho
             * 3.Es el mismo nodo
             */
            int comparador = string.Compare(nickName_, actualRaiz.nickName);
            if(comparador < 0)
            {
                if(actualRaiz.childsLeft == null)
                {
                    ABBNode newNode = new ABBNode(nickName_, password_, email_, conectado_, lstJuego_);
                    actualRaiz.childsLeft = newNode;
                }
                else
                {
                    insertABB(actualRaiz.childsLeft, nickName_, password_, email_, conectado_, lstJuego_);
                }
            }
            else if (comparador > 0)
            {
                if (actualRaiz.childsRight == null)
                {
                    ABBNode newNode = new ABBNode(nickName_, password_, email_, conectado_, lstJuego_);
                    actualRaiz.childsRight = newNode;
                }
                else
                {
                    insertABB(actualRaiz.childsRight, nickName_, password_, email_, conectado_, lstJuego_);
                }
            }
            else
            {
                Console.WriteLine("Nodo Existente");
                Console.ReadLine();
            }
        }

        /*
         * Eliminar Nodo ABB
         */
        public void destroyedNodeABB(ref ABBNode actualRaiz, string nickName_)
        {
            if(actualRaiz != null)
            {
                int comparador = string.Compare(nickName_, actualRaiz.nickName);

                if(comparador < 0)
                {
                    destroyedNodeABB(ref actualRaiz.childsLeft, nickName_);
                }
                else if (comparador > 0)
                {
                    destroyedNodeABB(ref actualRaiz.childsRight, nickName_);
                }
                else
                {
                    ABBNode auxNode = actualRaiz;
                    if (auxNode.childsRight == null)
                    {
                        actualRaiz = auxNode.childsLeft;
                    }
                    else if (auxNode.childsLeft == null)
                    {
                        actualRaiz = auxNode.childsRight;
                    }
                    else
                    {
                        ABBNode aux2Node = null;
                        ABBNode aux3Node = actualRaiz.childsLeft;
                        bool bandera = false;

                        while (aux3Node.childsRight != null)
                        {
                            aux2Node = aux3Node;
                            aux3Node = aux2Node.childsRight;
                            bandera = true;
                        }

                        actualRaiz.nickName = aux3Node.nickName;
                        actualRaiz.password = aux3Node.password;
                        actualRaiz.email = aux3Node.email;
                        actualRaiz.conectado = aux3Node.conectado;
                        actualRaiz.lstJuego = aux3Node.lstJuego;
                        actualRaiz.winGames = aux3Node.winGames;
                        actualRaiz.destroyedUnit = aux3Node.destroyedUnit;

                        aux2Node = aux3Node;
                        if(bandera == true)
                        {
                            aux2Node.childsRight = aux3Node.childsLeft;
                        }
                        else
                        {
                            actualRaiz.childsLeft = aux3Node.childsLeft;
                        }
                    }
                }
            }
        }

        /*
         * Cantidad de hojas
         */
        public int childsNodesABB()
        {
            return childsNodes(root);
        }

        private int childsNodes(ABBNode actualRaiz)
        {
            if (actualRaiz != null)
            {
                if((actualRaiz.childsLeft == null) && (actualRaiz.childsRight == null))
                {
                    return 1;
                }
                else
                {
                    return childsNodes(actualRaiz.childsLeft) + childsNodes(actualRaiz.childsRight);
                }
            }
            return 0;
        }

        /*
         * Nivel del Arbol
         */
        public int levelMaxABB()
        {
            if(root != null)
            {
                levelMaxABB(root);
            }
            return -1;
        }

        private int levelMaxABB(ABBNode actualRaiz)
        {
            if (actualRaiz != null)
            {
                if ((actualRaiz.childsLeft != null) || (actualRaiz.childsRight != null))
                {
                    int countLeft = levelMaxABB(actualRaiz.childsLeft);
                    int countRight = levelMaxABB(actualRaiz.childsRight);
                    return 1 + Math.Max(countLeft, countRight);
                }
            }
            return 0;
        }

        /*
         * Altura ABB
         */
        public int highAltitud()
        {
            return highAltitud(root);
        }
        private int highAltitud(ABBNode actualRaiz)
        {
            if(actualRaiz != null)
            {
                if ((actualRaiz.childsLeft != null) || (actualRaiz.childsRight != null))
                {
                    int pathLeft = highAltitud(actualRaiz.childsLeft);
                    int pathRight = highAltitud(actualRaiz.childsRight);
                    if (pathRight > pathLeft)
                    {
                        return pathRight + 1;
                    }
                    else
                    {
                        return pathLeft + 1;
                    }
                }
                return 1;
            }
            return 0;
        }

        /*
         * Cantidad de Nodos Rama
         */
        public int branches()
        {
            int ramastotales = branches(root) - childsNodesABB() - 1;
            return ramastotales;
        }

        private int branches(ABBNode actualRaiz)
        {
            int contador;

            if(actualRaiz!= null)
            {
                int branchesLeft = branches(actualRaiz.childsLeft);
                int branchesRight = branches(actualRaiz.childsRight);
                contador = branchesLeft + branchesRight + 1;
                return contador;
            }
            return 0;
        }

        /*
         * Graficar Arbol
         * 1. ABB
         * 2. AE
         */
        string graphABB;//Arbol Binario Busqueda
        string graphAE;//Arbol Espejo

        public void graficarABB()
        {
            graphABB = "";
            System.IO.StreamWriter f = new System.IO.StreamWriter("c:/Estructuras/ArbolBB.txt");
            f.Write("digraph arbolbb{ rankdir=TB;\nnode[shape = record,height = .1, color = blue]; ");

            if (root != null)
            {
                graficarABB(root);
                graficarABB_LD(root);
            }

            f.Write(graphABB);
            f.Write("}");
            f.Close();
        }

        private void graficarABB(ABBNode actualRaiz)
        {
            if (actualRaiz != null)
            {
                graphABB += "\nnodo" + actualRaiz.nickName.ToString() + "[label=\" <f0> |<f1> " + actualRaiz.nickName.ToString() + " \nEmail: " + actualRaiz.email + " \nConectado: " + actualRaiz.conectado.ToString() + " |<f2>\"]; \n";
                if (actualRaiz.childsLeft != null)
                {
                    graficarABB(actualRaiz.childsLeft);
                    graphABB += "\n\"nodo" + actualRaiz.nickName.ToString() + "\":f0 -> \"nodo" + actualRaiz.childsLeft.nickName.ToString() + "\":f1;";
                }

                if (actualRaiz.childsRight != null)
                {
                    graficarABB(actualRaiz.childsRight);
                    graphABB += "\n\"nodo" + actualRaiz.nickName.ToString() + "\":f2 -> \"nodo" + actualRaiz.childsRight.nickName.ToString() + "\":f1;";
                }
            }
        }

        int contador;
        private void graficarABB_LD(ABBNode actualRaiz)
        {
            if(actualRaiz.childsLeft != null)
            {
                graficarABB_LD(actualRaiz.childsLeft);
            }
            /*
             * Centro
             */
            if (actualRaiz.lstJuego.ini != null)
            {
                ListaDobleNode auxNode = actualRaiz.lstJuego.ini;
                contador = 0;
                while (auxNode != null)
                {
                    graphABB += "\nnodo" + auxNode.nickNameB + contador.ToString() + "[label=\"" + auxNode.nickName + "\nUnidades Desplegadas: " + auxNode.unfoldedUnits.ToString() + "\nUnidades Sobrevivientes: " + auxNode.survivingUnits.ToString() + "\nGanador: " + auxNode.winner.ToString() + "\nUnidades Desturidas: " + auxNode.destroyedUnits.ToString().Replace("\"", "\\\"") + " \", fillcolor=\"LightBlue\", style =\"filled\", shape=\"box\"]; \n";
                    contador = contador + 1;
                    auxNode = auxNode.siguiente;
                }

                contador = 0;
                string actual = "";
                string sig = "";
                auxNode = actualRaiz.lstJuego.ini;

                graphABB += "\n\"nodo" + actualRaiz.nickName.ToString() + "\":f1 -> \"nodo" + auxNode.nickNameB + contador.ToString() + "\";";

                while (auxNode != null)
                {
                    if (auxNode.siguiente != null)
                    {
                        actual = "nodo" + auxNode.nickNameB + contador.ToString();
                        contador = contador + 1;
                        sig = "nodo" + auxNode.siguiente.nickNameB + contador.ToString();
                        graphABB += actual + " -> " + sig + ";\n";
                        graphABB += sig + " -> " + actual + ";\n";
                    }
                    auxNode = auxNode.siguiente;
                }
            }

            if (actualRaiz.childsRight != null)
            {
                graficarABB_LD(actualRaiz.childsRight);
            }
        }

        public void graficarAE()
        {
            graphAE = "";
            System.IO.StreamWriter f = new System.IO.StreamWriter("c:/Estructuras/ArbolEspejo.txt");
            f.Write("digraph arbole{ rankdir=TB;\nnode[shape = record,height = .1, color = blue]; ");

            if (root != null)
            {
                graficarAE(root);
            }

            f.Write(graphAE);
            f.Write("}");
            f.Close();
        }

        private void graficarAE(ABBNode actualRaiz)
        {
            if(actualRaiz != null)
            {
                graphAE += "\nnodo" + actualRaiz.nickName + "[label=\" <f0> |<f1> " + actualRaiz.nickName + " \nEmail: " + actualRaiz.email + " \nConectado: " + actualRaiz.conectado.ToString() + " |<f2>\"]; \n";

                graficarAE(actualRaiz.childsLeft);

                if (actualRaiz.childsRight != null)
                {
                    graphAE += "\n\"nodo" + actualRaiz.nickName.ToString() + "\":f0 -> \"nodo" + actualRaiz.childsRight.nickName.ToString() + "\":f1;";
                }

                graficarAE(actualRaiz.childsRight);

                if (actualRaiz.childsLeft != null)
                {
                    graphAE += "\n\"nodo" + actualRaiz.nickName.ToString() + "\":f2 -> \"nodo" + actualRaiz.childsLeft.nickName.ToString() + "\":f1;";
                }
            }
        }

        /*
         * Lista de Juegos
         */
        public void insertLDGames(ABBNode actualRaiz, string nickName_B, string nickName_O, int unfoldedUnits_, int survivingUnits_, int destroyedUnits_, bool winner_)
        {
            int comparador = string.Compare(nickName_B, actualRaiz.nickName);
            if (actualRaiz != null)
            {                
                if (comparador < 0)
                {
                    if (actualRaiz.childsLeft == null)
                    {
                        Console.WriteLine("ERROR, No se encuentra el Nodo...");
                        Console.ReadLine();
                    }
                    else
                    {
                        insertLDGames(actualRaiz.childsLeft, nickName_B, nickName_O, unfoldedUnits_, survivingUnits_, destroyedUnits_, winner_);
                    }
                }
                else if (comparador > 0)
                {
                    if (actualRaiz.childsRight == null)
                    {
                        Console.WriteLine("ERROR, No se encuentra el Nodo...");
                        Console.ReadLine();
                    }
                    else
                    {
                        insertLDGames(actualRaiz.childsRight, nickName_B, nickName_O, unfoldedUnits_, survivingUnits_, destroyedUnits_, winner_);
                    }
                }
                else
                {
                    actualRaiz.lstJuego.insertLD(nickName_B, nickName_O, unfoldedUnits_, survivingUnits_, destroyedUnits_, winner_);
                }
            }
        }
    }
}