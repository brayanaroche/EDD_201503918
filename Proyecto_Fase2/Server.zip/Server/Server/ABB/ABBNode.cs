﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Server.ABB
{
    public class ABBNode
    {
        public string nickName;
        public string password;
        public string email;
        public int conectado;
        public ListaDoble lstJuego;
        
        /*
         * Variables para los reportes
         */
        public int winGames;
        public int destroyedUnit;

        /*
         * Hijo Izquierdo e Hijo Derecho
         */
        public ABBNode childsRight;
        public ABBNode childsLeft;

        /*
         * Constructor para un nuevo Nodo
         */
        public ABBNode(string nickName_, string password_, string email_, int conectado_, ListaDoble lstJuego_)
        {
            this.nickName = nickName_;
            this.password = password_;
            this.email = email_;
            this.conectado = conectado_;
            this.lstJuego = lstJuego_;
            /*
             * Valores a donde apuntan el hijo izq y der
             */
            this.childsRight = null;
            this.childsLeft = null;
        }
    }
}