﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Server.ABB
{
    public class ListaDoble
    {
        public ListaDobleNode ini;
        public ListaDobleNode fin;
        
        /*
         * Constructor LD
         */
        public ListaDoble()
        {
            ini = null;
            fin = null;
        }

        /*
         * Insertar LD Juego
         * Unfolded units = unidades desplegadas
         * Destroyed Units = unidades destruidas
         * winner = ganador
         * surviving units = unidades sobrevivientes
         */
        public void insertLD(string nickNameB_, string nickName_, int unfoldedUnits_, int survivingUnits_, int destroyedUnits_, bool winner_)
        {
            ListaDobleNode newNode = new ListaDobleNode(nickNameB_, nickName_, unfoldedUnits_, survivingUnits_, destroyedUnits_, winner_);

            if(ini == null)
            {
                newNode.siguiente = fin;
                newNode.anterior = ini;
                fin = newNode;
                ini = newNode;
            }
            else
            {
                newNode.siguiente = null;
                newNode.anterior = fin;
                fin.siguiente = newNode;
                fin = newNode;
            }
        }
    }
}