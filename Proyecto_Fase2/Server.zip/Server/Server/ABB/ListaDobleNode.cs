﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Server.ABB
{
    public class ListaDobleNode
    {
        public string nickNameB;
        public string nickName;
        public int unfoldedUnits;
        public int survivingUnits;
        public int destroyedUnits;
        public bool winner;

        /*
         * Apuntadores del nodo
         */
        public ListaDobleNode siguiente;
        public ListaDobleNode anterior;

        /*
         * Constructor ListaDobleNode
         */
        public ListaDobleNode(string nickNameB_, string nickName_, int unfoldeUnits_, int survivingUnits_, int destroyedUnits_, bool winner_)
        {
            this.nickNameB = nickNameB_;
            this.nickName = nickName_;
            this.unfoldedUnits = unfoldeUnits_;
            this.survivingUnits = survivingUnits_;
            this.destroyedUnits = destroyedUnits_;
            this.winner = winner_;
        }
    }
}