﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Server.ABB;
using Server.AVL;
using Server.Matriz;
using System.IO;

namespace Server
{
    /// <summary>
    /// Descripción breve de WebServer
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class WebServer : System.Web.Services.WebService
    {

        /*
         * Variables estaticas para las otras clase
         */
        static ABB_ newArbol = new ABB_();
        static AVL_ newAVL = new AVL_();
        static Matriz_ newMatriz = new Matriz_(2);

        [WebMethod]
        public string HelloWorld()
        {
            return "Hola a todos";
        }

        /*
         * Insertar Arbol, Lista Doble, AVL
         */
        [WebMethod]
        public string insertABB(string nickName_, string password_, string email_, int conectado_)
        {
            ListaDoble newList = new ListaDoble();
            newArbol.insertABB(nickName_, password_, email_, conectado_, newList);
            return "Se inserto Usuario";
        }

        [WebMethod]
        public string listGame(string nickName_B, string nickName_O, int unfoldedUnits_, int survivingUnits_, int destroyedUnits_, int winner_)
        {
            if(winner_ == 0)
            {
                newArbol.insertLDGames(newArbol.root, nickName_B, nickName_O, unfoldedUnits_, survivingUnits_, destroyedUnits_, false);
            }
            else
            {
                newArbol.insertLDGames(newArbol.root, nickName_B, nickName_O, unfoldedUnits_, survivingUnits_, destroyedUnits_, true);
            }
            return "Se inserto Juego";
        }

        [WebMethod]
        public string insertAVL(string nickName_, string password_, string email_)
        {
            newAVL.insertAVL(nickName_, password_, email_);
            return "Se inserto nodo";
        }

        [WebMethod]
        public string insertMatriz(string nickName_, string unitName_, int typeUnit, int row_, int column_, int level_)
        {
            UnitsNode units_ = new UnitsNode(nickName_, unitName_, level_, typeUnit);
            newMatriz.insertMatriz(units_, row_, column_);
            return "Se inserto unidad";
        }
        
        /*
         * Graficar Arbol BB, Arbol E, AVL
         */
        [WebMethod]
        public string graphABB()
        {
            newArbol.graficarABB();            
            GraficarEDD("ArbolBB.txt", "c:/Estructuras/");            
            return "Se grafico ABB";
        }

        [WebMethod]
        public string graphAE()
        {
            newArbol.graficarAE();
            GraficarEDD("ArbolEspejo.txt", "c:/Estructuras/");
            return "Se grafico AE";
        }

        [WebMethod]
        public string graphAVL()
        {
            newAVL.graficarAVL();
            GraficarEDD("AVL.txt", "c:/Estructuras/");
            return "Se grafico AVL";
        }

        [WebMethod]
        public string graphMatriz(int level_)
        {
            newMatriz.graficarMatriz(level_);
            GraficarEDD("matrizNivel" + level_.ToString() + ".txt", "C:/Estructuras");
            return "Se grafico Matriz";
        }

        public void GraficarEDD(string fileName, string path)
        {
            try
            {
                var command = string.Format("dot.exe -Tjpg {0} -o {1}", Path.Combine(path, fileName), Path.Combine(path, fileName.Replace(".txt", ".jpg")));
                var procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/C " + command);
                var proc = new System.Diagnostics.Process();
                proc.StartInfo = procStartInfo;
                proc.Start();
                proc.WaitForExit();
            }
            catch (Exception x)
            {

            }
        }
    }
}
