﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Server.ABB;

namespace Server.AVL
{
    public class AVLNode
    {
        public string nickName;
        public string password;
        public string email;
        //public ABBNode user;

        public AVLNode childLeft;
        public AVLNode childRight;
        public AVLNode cabeza;
        public AVLNode(string nickName_, string password_, string email_, AVLNode childLeft_, AVLNode childRight_, AVLNode cabeza_)//, ABBNode user_)
        {
            nickName = nickName_;
            password = password_;
            email = email_;
            //user = user_;
            childLeft = childLeft_;
            childRight = childRight_;
            cabeza = cabeza_;
        }
    }
}