﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Server.ABB;

namespace Server.AVL
{
    public class AVL_
    {
        /*
         * Raiz
         */
        AVLNode root;

        /*
         * Constructor clase AVL
         */
        public AVL_()
        {
            root = new AVLNode(null, null, null, null, null, null);
        }

        /*
         * Insertar
         */
        public void insertAVL(string nickName_, string password_, string email_)//, ABBNode user_)
        {
            insertAVL(nickName_, password_, email_, root);
        }

        private void insertAVL(string nickName_, string password_, string email_, AVLNode actualRaiz)//ABBNode user_, 
        {
            if (actualRaiz.nickName == null)
            {
                actualRaiz.nickName = nickName_;
                actualRaiz.password = password_;
                actualRaiz.email = email_;
                balancear(actualRaiz);
            }
            else
            {
                int comparador = String.Compare(nickName_, actualRaiz.nickName);
                if (comparador > 0)
                {
                    if (actualRaiz.childRight == null)
                        actualRaiz.childRight = new AVLNode(null, null, null, null, null, actualRaiz);
                    insertAVL(nickName_, password_, email_, actualRaiz.childRight);
                }
                else if (comparador < 0)
                {
                    if (actualRaiz.childLeft == null)
                        actualRaiz.childLeft = new AVLNode(null, null, null, null, null, actualRaiz);                    
                    insertAVL(nickName_, password_, email_, actualRaiz.childLeft);
                }
                else
                {
                    Console.WriteLine("Nodo Existente");
                    Console.ReadLine();
                }
            }
        }

        /*
         * Factor de Equilibrio
         */
        private int factorEquilibrio(AVLNode actualRaiz)
        {
            if (actualRaiz.childRight != null && actualRaiz.childLeft != null)
                return altura(actualRaiz.childRight) - altura(actualRaiz.childLeft);
            else if (actualRaiz.childRight == null && actualRaiz.childLeft != null)
                return 0 - altura(actualRaiz.childLeft) - 1;
            else if (actualRaiz.childRight != null && actualRaiz.childLeft == null)
                return altura(actualRaiz.childRight) + 1;
            else
                return 0;
        }

        /*
         * Balanceo
         */
        private void balancear(AVLNode actualRaiz)
        {
            if (Math.Abs(factorEquilibrio(actualRaiz)) >= 2)
            {
                if (factorEquilibrio(actualRaiz) == 2)
                {
                    if (factorEquilibrio(actualRaiz.childRight) >= 0)
                    {
                        //Rotacion derecha derecha
                        rotations(actualRaiz, "RR");
                    }
                    else if(factorEquilibrio(actualRaiz.childRight) < 0)
                    {
                        //Rotacion derecha izquierda
                        rotations(actualRaiz, "RL");
                    }
                }
                else if(factorEquilibrio(actualRaiz) == -2)
                {
                    if (factorEquilibrio(actualRaiz.childLeft) > 0)
                    {
                        //Rotacion izquierda derecha
                        rotations(actualRaiz, "LR");
                    }
                    else if (factorEquilibrio(actualRaiz.childLeft) <= 0)
                    {
                        //Rotacion izquierda izquierda
                        rotations(actualRaiz, "LL");
                    }
                }
            }
            else
            {
                if (actualRaiz.cabeza != null)
                    balancear(actualRaiz.cabeza);
            }
        }

        /*
         * Calcular Altura
         */
        private int altura(AVLNode actualRaiz)
        {
            return altura(actualRaiz, 0) - 1;
        }
                
        private int altura(AVLNode actualRaiz, int contador_)
        {
            int contador = contador_ + 1;
            if (actualRaiz.childRight != null && actualRaiz.childLeft == null)
                return altura(actualRaiz.childRight, contador);
            else if (actualRaiz.childRight == null && actualRaiz.childLeft != null)
                return altura(actualRaiz.childLeft, contador);
            else if (actualRaiz.childLeft == null && actualRaiz.childRight == null)
                return contador;
            else //if (actualRaiz.childRight != null && actualRaiz.childLeft != null)            
                if (altura(actualRaiz.childRight, contador) > altura(actualRaiz.childLeft, contador))
                    return altura(actualRaiz.childRight, contador);
                else
                    return altura(actualRaiz.childLeft, contador);
            //return 0;
        }

        /*
         * Rotaciones LL, LR, RR, RL
         */
        private void rotations(AVLNode actualRaiz, string rotacion_)
        {
            if (rotacion_.Equals("LL"))
            {
                rotationtLeft(actualRaiz);
            }
            else if (rotacion_.Equals("LR"))
            {
                rotationtLeft(actualRaiz);
                rotationtRight(actualRaiz);                
            }
            else if (rotacion_.Equals("RL"))
            {
                rotationtRight(actualRaiz);
                rotationtLeft(actualRaiz);
            }
            else if (rotacion_.Equals("RR"))
            {
                rotationtRight(actualRaiz);
            }
        }

        private void rotationtLeft(AVLNode actualRaiz)
        {
            if (actualRaiz.cabeza == null)
            {
                if (actualRaiz.childLeft.childRight != null)
                {
                    AVLNode temp1 = actualRaiz.childLeft;
                    AVLNode temp2 = actualRaiz.childLeft.childRight;
                    temp1.childRight = actualRaiz;
                    actualRaiz.cabeza = temp1;
                    actualRaiz.childLeft = temp2;
                    temp2.cabeza = actualRaiz;
                    temp1.cabeza = null;
                    root = temp1;
                }
                else
                {
                    AVLNode temp1 = actualRaiz.childLeft;
                    temp1.childRight = actualRaiz;
                    actualRaiz.cabeza = temp1;
                    actualRaiz.childLeft = null;
                    temp1.cabeza = null;
                    root = temp1;
                }
            }
            else
            {
                if (actualRaiz.cabeza.childRight == actualRaiz)
                {
                    if (actualRaiz.childLeft.childRight != null)
                    {
                        AVLNode temp1 = actualRaiz.cabeza;
                        AVLNode temp2 = actualRaiz.childLeft;
                        AVLNode temp3 = actualRaiz.childLeft.childRight;
                        temp1.childRight = temp2;
                        temp2.cabeza = temp1;
                        temp2.childRight = actualRaiz;
                        actualRaiz.cabeza = temp2;
                        actualRaiz.childLeft = temp3;
                        temp3.cabeza = actualRaiz;
                    }
                    else
                    {
                        AVLNode temp1 = actualRaiz.cabeza;
                        AVLNode temp2 = actualRaiz.childLeft;
                        temp1.childRight = temp2;
                        temp2.cabeza = temp1;
                        temp2.childRight = actualRaiz;
                        actualRaiz.cabeza = temp2;
                        actualRaiz.childLeft = null;
                    }
                }
                else if (actualRaiz.cabeza.childLeft == actualRaiz)
                {
                    if (actualRaiz.childLeft.childRight != null)
                    {
                        AVLNode temp1 = actualRaiz.cabeza;
                        AVLNode temp2 = actualRaiz.childLeft;
                        AVLNode temp3 = actualRaiz.childLeft.childRight;
                        temp1.childLeft = temp2;
                        temp2.cabeza = temp1;
                        temp2.childRight = actualRaiz;
                        actualRaiz.cabeza = temp2;
                        actualRaiz.childLeft = temp3;
                        temp3.cabeza = actualRaiz;
                    }
                    else
                    {
                        AVLNode temp1 = actualRaiz.cabeza;
                        AVLNode temp2 = actualRaiz.childLeft;
                        temp1.childLeft = temp2;
                        temp2.cabeza = temp1;
                        temp2.childRight = actualRaiz;
                        actualRaiz.cabeza = temp2;
                        actualRaiz.childLeft = null;
                    }
                }
            }
        }

        private void rotationtRight(AVLNode actualRaiz)
        {
            if (actualRaiz.cabeza == null)
            {
                if (actualRaiz.childRight.childLeft != null)
                {
                    AVLNode temp1 = actualRaiz.childRight;
                    AVLNode temp2 = actualRaiz.childRight.childLeft;
                    temp1.childLeft = actualRaiz;
                    actualRaiz.cabeza = temp1;
                    actualRaiz.childRight = temp2;
                    temp2.cabeza = actualRaiz;
                    temp1.cabeza = null;
                    root = temp1;                                        
                }
                else
                {
                    AVLNode temp1 = actualRaiz.childRight;
                    temp1.childLeft = actualRaiz;
                    actualRaiz.cabeza = temp1;
                    actualRaiz.childRight = null;
                    temp1.cabeza = null;
                    root = temp1;                    
                }
            }
            else
            {
                if (actualRaiz.cabeza.childRight == actualRaiz)
                {
                    if (actualRaiz.childRight.childLeft != null)
                    {
                        AVLNode temp1 = actualRaiz.cabeza;
                        AVLNode temp2 = actualRaiz.childRight;
                        AVLNode temp3 = actualRaiz.childRight.childLeft;
                        temp1.childRight = temp2;
                        temp2.cabeza = temp1;
                        temp2.childLeft = actualRaiz;
                        actualRaiz.cabeza = temp2;
                        actualRaiz.childRight = temp3;
                        temp3.cabeza = actualRaiz;
                    }
                    else
                    {
                        AVLNode temp1 = actualRaiz.cabeza;
                        AVLNode temp2 = actualRaiz.childRight;
                        temp1.childRight = temp2;
                        temp2.cabeza = temp1;
                        temp2.childLeft = actualRaiz;
                        actualRaiz.cabeza = temp2;
                        actualRaiz.childRight = null;
                    }
                }
                else if (actualRaiz.cabeza.childLeft == actualRaiz)
                {
                    if (actualRaiz.childRight.childLeft != null)
                    {
                        AVLNode temp1 = actualRaiz.cabeza;
                        AVLNode temp2 = actualRaiz.childRight;
                        AVLNode temp3 = actualRaiz.childRight.childLeft;
                        temp1.childLeft = temp2;
                        temp2.cabeza = temp1;
                        temp2.childLeft = actualRaiz;
                        actualRaiz.cabeza = temp2;
                        actualRaiz.childRight = temp3;
                        temp3.cabeza = actualRaiz;
                    }
                    else
                    {
                        AVLNode temp1 = actualRaiz.cabeza;
                        AVLNode temp2 = actualRaiz.childRight;
                        temp1.childLeft = temp2;
                        temp2.cabeza = temp1;
                        temp2.childLeft = actualRaiz;
                        actualRaiz.cabeza = temp2;
                        actualRaiz.childRight = null;
                    }
                }
            }
        }

        /*
         * Graficar AVL
         */
        string graphAVL;
        public void graficarAVL()
        {
            graphAVL = "";
            System.IO.StreamWriter f = new System.IO.StreamWriter("c:/Estructuras/AVL.txt");
            f.Write("digraph avl{ rankdir=TB;\nnode[shape = record,height = .05, color = blue]; ");

            if (root != null)
            {
                graficarAVL(root);
            }

            f.Write(graphAVL);
            f.Write("}");
            f.Close();
        }

        private void graficarAVL(AVLNode actualRaiz)
        {
            if (actualRaiz != null)
            {
                graphAVL += "\nnodo" + actualRaiz.nickName.ToString() + "[label=\" <f0> |<f1> " + actualRaiz.nickName.ToString() + " \nEmail: " + actualRaiz.email + " \nPassword: " + actualRaiz.password.ToString() + " |<f2>\"]; \n";
                if (actualRaiz.childLeft != null)
                {
                    graficarAVL(actualRaiz.childLeft);
                    graphAVL += "\n\"nodo" + actualRaiz.nickName.ToString() + "\":f0 -> \"nodo" + actualRaiz.childLeft.nickName.ToString() + "\":f1;";
                }

                if (actualRaiz.childRight != null)
                {
                    graficarAVL(actualRaiz.childRight);
                    graphAVL += "\n\"nodo" + actualRaiz.nickName.ToString() + "\":f2 -> \"nodo" + actualRaiz.childRight.nickName.ToString() + "\":f1;";
                }
            }
        }
    }
}