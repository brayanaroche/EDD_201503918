﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Server.Matriz
{
    public class UnitsNode
    {
        /*
         * Atributos del nodo matriz
         * idUnit es para ver si es submarino, barco, satellite o avion
         * unit es para saber si es bombardero, neosatelite, caza, etc.
         * move cantidad de movimientos que puede tener la unidad
         * hurt daño que puede hacer al disparar
         * live vida que posee la unidad actualmente
         * scope el alcance que posee la unidad
         * nickName nombre del jugador
         * alive si la unidad aun sigue con vida
         */
        public string nickName, idUnit, Unit;
        public int live, move, scope, hurt, typeUnit, level;
        public bool alive;

        /*
         * Constructor nodo unidades
         */
        public UnitsNode(string nickName_, string unitName_, int level_, int typeUnit_)
        {
            nickName = nickName_;
            if (level_ == 1)
            {
                if (typeUnit_ == 1)
                {
                    idUnit = "Submarinos";
                    Unit = unitName_;
                    live = 10;
                    move = 5;
                    scope = 1;
                    hurt = 2;
                    typeUnit = 1;
                    level = 1;
                    alive = true;
                }
            }
            else if(level_ == 2)
            {
                if (typeUnit_ == 1)
                {
                    idUnit = "Barcos";
                    Unit = unitName_;
                    live = 10;
                    move = 5;
                    scope = 6;
                    hurt = 3;
                    typeUnit = 1;
                    level = 2;
                    alive = true;
                }
                else if (typeUnit_ == 2)
                {
                    idUnit = "Barcos";
                    Unit = unitName_;
                    live = 15;
                    move = 6;
                    scope = 1;
                    hurt = 3;
                    typeUnit = 2;
                    level = 2;
                    alive = true;
                }
            }
            else if (level_ == 3)
            {
                if (typeUnit_ == 1)
                {
                    idUnit = "Aviones";
                    Unit = unitName_;
                    live = 10;
                    move = 7;
                    scope = 0;
                    hurt = 5;
                    typeUnit = 1;
                    level = 3;
                    alive = true;
                }
                else if (typeUnit_ == 2)
                {
                    idUnit = "Aviones";
                    Unit = unitName_;
                    live = 20;
                    move = 9;
                    scope = 1;
                    hurt = 2;
                    typeUnit = 2;
                    level = 3;
                    alive = true;
                }
                else if (typeUnit_ == 3)
                {
                    idUnit = "Aviones";
                    Unit = unitName_;
                    live = 15;
                    move = 9;
                    scope = 1;
                    hurt = 3;
                    typeUnit = 3;
                    level = 3;
                    alive = true;
                }
            }
            else if (level_ == 4)
            {
                if (typeUnit_ == 1)
                {
                    idUnit = "Satelltes";
                    Unit = unitName_;
                    live = 10;
                    move = 6;
                    scope = 0;
                    hurt = 2;
                    typeUnit = 1;
                    level = 4;
                    alive = true;
                }
            }
        }
    }
}