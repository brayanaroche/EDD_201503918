﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Server.Matriz
{
    public class Cabecera
    {
        public CabeceraNode ini;

        /*
         * Constructor de cabecera
         */
        public Cabecera()
        {
            ini = null;
        }

        /*
         * Metodo insertar
         */
        public void insertCabeceraNode(int indice_)
        {
            CabeceraNode newNode = new CabeceraNode(indice_);
            if (ini == null)
            {
                ini = newNode;
            }
            else
            {
                if (ini.indice > newNode.indice)
                {
                    newNode.siguiente = ini;
                    ini.anterior = newNode;
                    ini = newNode;
                }
                else
                {
                    CabeceraNode auxNode = ini;
                    while (auxNode.siguiente != null)
                    {
                        if (auxNode.siguiente.indice > newNode.indice)
                        {
                            newNode.siguiente = auxNode.siguiente;
                            newNode.anterior = auxNode;
                            auxNode.siguiente.anterior = newNode;
                            auxNode.siguiente = newNode;
                            break;
                        }
                    }
                    if (auxNode.siguiente == null)
                    {
                        newNode.anterior = auxNode;
                        auxNode.siguiente = newNode;
                    }
                }
            }
        }

        /*
         * Obteniendo indice
         */
        public CabeceraNode findCabeceraNode(int indice)
        {
            CabeceraNode nodoActual = ini;

            while (nodoActual != null)
            {
                if (nodoActual.indice == indice)
                {
                    return nodoActual;
                }
                nodoActual = nodoActual.siguiente;
            }

            return null;
        }

        /*
         * Metodo Eliminar
         */
        public string deletedCabeceraNode(int indice)
        {
            CabeceraNode nodoDestroyed = findCabeceraNode(indice);
            if (nodoDestroyed.indice > ini.indice)
            {
                if (nodoDestroyed.indice == indice)
                {
                    if (nodoDestroyed.anterior != null)
                    {
                        nodoDestroyed.anterior.siguiente = nodoDestroyed.siguiente;
                        return "Cambio para no perder enlace";
                    }
                    if (nodoDestroyed.siguiente != null)
                    {
                        nodoDestroyed.siguiente.anterior = nodoDestroyed.anterior;
                        return "Cambio para no perder enlace";
                    }
                }
                if (nodoDestroyed.siguiente == null)
                {
                    nodoDestroyed.anterior.siguiente = null;
                    return "Nodo Destruido";
                }
            }
            else
            {
                ini = nodoDestroyed.siguiente;
                return "Nodo Destruido, ini = siguiente nodo";
            }

            return "Nodo no Existente";
        }
    }
}