﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Server.Matriz
{
    public class MatrizNode
    {
        /*
         * Unidades
         */
        public UnitsNode units;
        /*
         * Coordenadas x, y, z
         */
        public int coor_x, coor_y;

        /*
         * Apuntadores del nodo matriz
         */
        public MatrizNode left, right, up, down, front, back;

        /*
         * Constructor del nodo matriz
         */
        public MatrizNode(UnitsNode units_, int coor_x_, int coor_y_)
        {
            coor_x = coor_x_;
            coor_y = coor_y_;
            units = units_;
            left = null;
            right = null;
            up = null;
            down = null;
            front = null;
            back = null;
        }
    }
}