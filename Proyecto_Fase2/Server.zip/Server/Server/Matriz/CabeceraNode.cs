﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Server.Matriz
{
    public class CabeceraNode
    {
        /*
         * Atributo Indice 
         */
        public int indice;
        /*
         * Apuntadores de los encabezados
         */
        public CabeceraNode siguiente;
        public CabeceraNode anterior;

        /*
         * Acceso a matriz
         */
        public MatrizNode accesoBarco;

        /*
         * Constructor de nodo cabecera
         */
        public CabeceraNode(int indice_)
        {
            indice = indice_;
            siguiente = null;
            anterior = null;
            accesoBarco = null;
        }
    }
}