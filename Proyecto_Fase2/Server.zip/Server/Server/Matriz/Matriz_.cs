﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Server.Matriz
{
    public class Matriz_
    {
        /*
         * Instancia para las cabeceras en:
         * 1. filas
         * 2. columnas
         */
        private Cabecera row, column;

        /*
         * nivel para ubicar la unidad
         */
        private int level;

        /*
         * punteros de inicio y fin para la matriz y enlaces a los encabezados
         */
        private Matriz_ first, last;

        /*
         * Constructor de la matriz
         */
        public Matriz_(int level_)
        {
            level = level_;
            row = new Cabecera();
            column = new Cabecera();
            first = null;
            last = null;
        }

        /*
         * Insertar Matriz
         */
        public void insertMatriz(UnitsNode units_, int row_, int column_)
        {
            MatrizNode newNode = new MatrizNode(units_, row_, column_);
            Matriz_ matrizParcial = this;
            cabeceraCreate(matrizParcial, newNode,units_, row_, column_);
            cabeceraNodeRow(matrizParcial, newNode, units_, row_);
            cabeceraNodeColumn(matrizParcial, newNode, units_, column_);
            placeUnits(matrizParcial, newNode, row_, column_);
        }

        /*
         * Creando Acceso
         */
        private void cabeceraCreate(Matriz_ matrizParcial, MatrizNode newNode,UnitsNode units_, int row_, int column_)
        {            
            if (newNode.units.level == 1)
            {
                if (matrizParcial.last == null)
                    matrizParcial = matrizParcial.last;
                else
                {
                    matrizParcial.last = new Matriz_(1);
                    matrizParcial = matrizParcial.last;
                }
            }
            else if (newNode.units.level == 2)
            {
                if (matrizParcial.first != null)
                    matrizParcial = matrizParcial.first;
                else
                {
                    matrizParcial.first = new Matriz_(2);
                    matrizParcial = matrizParcial.first;
                }
            }
            else if (newNode.units.level == 3)
            {
                if (matrizParcial.first != null)
                {
                    matrizParcial = matrizParcial.first;
                    if (matrizParcial.first != null)
                        matrizParcial = matrizParcial.first;
                    else
                    {
                        matrizParcial.first = new Matriz_(3);
                        matrizParcial = matrizParcial.first;
                    }
                }
            }
            else if (newNode.units.level == 4)
            {
                if (matrizParcial.first != null)
                {
                    matrizParcial = matrizParcial.first;
                    if (matrizParcial.first != null)
                    {
                        matrizParcial = matrizParcial.first;
                        if (matrizParcial.first != null)
                            matrizParcial = matrizParcial.first;
                        else
                        {
                            matrizParcial.first = new Matriz_(4);
                            matrizParcial = matrizParcial.first;
                        }
                    }
                }
            }
        }
        
        /*
         * Creando Cabecera en Columna y  Fila
         */
        private void cabeceraNodeColumn(Matriz_ matrizParcial, MatrizNode newNode,UnitsNode units_, int column_)
        {
            CabeceraNode col = matrizParcial.column.findCabeceraNode(column_);
            if (col != null)
            {
                if (newNode.coor_x < col.accesoBarco.coor_x)
                {
                    col.accesoBarco.up = newNode;
                    newNode.down = col.accesoBarco;
                    col.accesoBarco = newNode;
                }
                else
                {
                    MatrizNode auxNode = col.accesoBarco;
                    while (auxNode.down != null)
                    {
                        if (newNode.coor_x < auxNode.down.coor_x)
                        {
                            newNode.down = auxNode.down;
                            newNode.up = auxNode;
                            auxNode.down.up = newNode;
                            auxNode.down = newNode;
                            break;
                        }
                        auxNode = auxNode.down;
                    }

                    if (auxNode.down == null)
                    {
                        auxNode.down = newNode;
                        newNode.up = auxNode;
                    }
                }
            }
            else
            {
                matrizParcial.column.insertCabeceraNode(column_);
                col = matrizParcial.column.findCabeceraNode(column_);
                col.accesoBarco = newNode;
            }
        }
        
        private void cabeceraNodeRow(Matriz_ matrizParcial, MatrizNode newNode, UnitsNode units_, int row_)
        {
            CabeceraNode rw = matrizParcial.row.findCabeceraNode(row_);
            if (rw != null)
            {
                if (newNode.coor_y < rw.accesoBarco.coor_y)
                {
                    rw.accesoBarco.left = newNode;
                    newNode.right = rw.accesoBarco;
                    rw.accesoBarco = newNode;
                }
                else
                {
                    MatrizNode auxNode = rw.accesoBarco;
                    while (auxNode.right != null)
                    {
                        if (newNode.coor_y < auxNode.right.coor_y)
                        {
                            newNode.right = auxNode.right;
                            newNode.left = auxNode;
                            auxNode.right.left = newNode;
                            auxNode.right = newNode;
                            break;
                        }
                        auxNode = auxNode.right;
                    }

                    if (auxNode.right == null)
                    {
                        auxNode.right = newNode;
                        newNode.left = auxNode;
                    }
                }
            }
            else
            {
                matrizParcial.row.insertCabeceraNode(row_);
                rw = matrizParcial.row.findCabeceraNode(row_);
                rw.accesoBarco = newNode;
            }
        }

        /*
         * buscar nodo matriz por:
         * fila
         * nombre de unidad
         */
        private MatrizNode findNodeUnit(string nameUnit)
        {
            MatrizNode findNodeUnit_ = null;
            CabeceraNode acceso = row.ini;
            while (acceso != null)
            {
                findNodeUnit_ = acceso.accesoBarco;
                while (findNodeUnit_ != null)
                {
                    int comparador = String.Compare(nameUnit, findNodeUnit_.units.Unit);
                    if (comparador == 0)
                    {
                        break;
                    }
                    findNodeUnit_ = findNodeUnit_.right;
                }
                if (findNodeUnit_ != null)
                {
                    break;
                }
                acceso = acceso.siguiente;
            }
            return findNodeUnit_;
        }

        private MatrizNode findNodeUnit(int row_, int column_)
        {
            MatrizNode findNode_ = null;
            CabeceraNode rw = row.findCabeceraNode(row_);
            if (rw != null)
            {
                findNode_ = rw.accesoBarco;
                while (findNode_ != null)
                {
                    if (findNode_.coor_y == column_)
                    {
                        break;
                    }
                    findNode_ = findNode_.right;
                }
            }
            return findNode_;
        }

        /*
         * Colocar Unidades
         */
        private void placeUnits(Matriz_ matrizParcial, MatrizNode newNode, int row_, int column_)
        {
            Matriz_ auxMatriz;
            MatrizNode tempNode;

            auxMatriz = matrizParcial.first;
            while (auxMatriz != null)
            {
                tempNode = auxMatriz.findNodeUnit(row_, column_);
                if (tempNode != null)
                {
                    newNode.up = tempNode;
                    tempNode.down = newNode;
                    break;
                }
                auxMatriz = auxMatriz.first;
            }

            auxMatriz = matrizParcial.last;
            while (auxMatriz != null)
            {
                tempNode = auxMatriz.findNodeUnit(row_, column_);
                if (tempNode != null)
                {
                    newNode.down = tempNode;
                    tempNode.up = newNode;
                    break;
                }
                auxMatriz = auxMatriz.last;
            }
        }

        /*
         * Graficar Matriz
         */
        string graphMatriz;
        public void graficarMatriz(int nivel)
        {
            graphMatriz = "";
            System.IO.StreamWriter f = new System.IO.StreamWriter("c:/Estructuras/matrizNivel" + nivel.ToString() + ".txt");

            /*
             * Encabezado del archivo dot para la matriz
             */
            f.Write("digraph matriz\n{\tnode[shape=box, style=filled, color=lightsteelblue3];\n\tedge[color=black];\n\trankdir=UD;\n");

            /*
             * Ordenar grafica
             */
            sentRank("matrizNivel" + nivel.ToString() + ".txt", nivel);
            /*
             * Columnas y Filas del metodo graficar
             */
            graphColumn("matrizNivel" + nivel.ToString() + ".txt", nivel);
            graphRow("matrizNivel" + nivel.ToString() + ".txt", nivel);


            /*
             * Enlazar los nodos de fila y columna
             */
            graphLinkColumnNode("matrizNivel" + nivel.ToString() + ".txt", nivel);
            graphLinkRowNode("matrizNivel" + nivel.ToString() + ".txt", nivel);
            graphLinkColumn("matrizNivel" + nivel.ToString() + ".txt", nivel);
            graphLinkRow("matrizNivel" + nivel.ToString() + ".txt", nivel);

            f.Write(graphMatriz);
            f.Write("\n}");
            f.Close();
        }

        /*
         * Buscar Nivel
         */
        private MatrizNode findLevel(MatrizNode findNode, int level)
        {
            MatrizNode auxNode = findNode;
            while (auxNode != null)
            {
                if (auxNode.units.level == level)
                    break;
                else
                    auxNode = auxNode.back;
            }
            return auxNode;
        }

        /*
         * Metodos privados para graicar
         */
        string fi;
        string col;
        string nodo;
        private void graphColumn(string title, int level)
        {
            CabeceraNode columnaGraficar = column.ini;

            while (columnaGraficar != null)
            {
                MatrizNode nodoActual = columnaGraficar.accesoBarco;
                while (nodoActual != null)
                {
                    MatrizNode nodoAux = findLevel(nodoActual, level);
                    if (nodoAux != null)
                    {
                        nodo = "\tnd" + nodoAux.coor_y.ToString() + nodoAux.coor_x.ToString() + nodoAux.units.level.ToString();
                        graphMatriz += nodo + ";\n\t" + nodo + "[label=\"" + "Unidad: " + nodoAux.units.Unit + "\nVida: " + nodoAux.units.live.ToString() + "\nAlcance: " + nodoAux.units.scope.ToString() + "\nDaño: " + nodoAux.units.hurt.ToString() + "\nNivel: " + nodoAux.units.level.ToString() + "\", color=gray75];\n\t";

                        if (findLevel(nodoActual.down, level) != null)
                        {
                            graphMatriz += nodo + " -> ";
                        }
                    }
                    nodoActual = nodoActual.down;
                }
                columnaGraficar = columnaGraficar.siguiente;
            }
        }
        private void graphRow(string title, int level)
        {
            CabeceraNode filaGraficar = row.ini;

            while (filaGraficar != null)
            {
                MatrizNode nodoActual = filaGraficar.accesoBarco;
                while (nodoActual != null)
                {
                    MatrizNode nodoAux = findLevel(nodoActual, level);
                    if (nodoAux != null)
                    {
                        nodo = "nd" + nodoAux.coor_y.ToString() + nodoAux.coor_x.ToString() + nodoAux.units.level.ToString();
                        graphMatriz += nodo + ";\n\t";

                        if (findLevel(nodoActual.right, level) != null)
                        {
                            graphMatriz += nodo + " ->";
                        }
                    }
                    nodoActual = nodoActual.right;
                }
                filaGraficar = filaGraficar.siguiente;
            }
        }
        private void graphLinkColumnNode(string title, int level)
        {
            CabeceraNode columnaGrafica = column.ini;
            while (columnaGrafica != null)
            {
                MatrizNode nodoActualGrafica = columnaGrafica.accesoBarco;
                col = "C" + columnaGrafica.indice.ToString();

                while (nodoActualGrafica != null)
                {
                    MatrizNode nodoAux = findLevel(nodoActualGrafica, level);
                    if (nodoAux != null)
                    {
                        nodo = "nd" + nodoAux.coor_y.ToString() + nodoAux.coor_x.ToString() + nodoAux.units.level.ToString();//Identificador para nodo                        
                        graphMatriz += col + " -> " + nodo + ";\n\t";
                        graphMatriz += nodo + " -> " + col + ";\n\t";
                        break;
                    }
                    nodoActualGrafica = nodoActualGrafica.down;
                }
                columnaGrafica = columnaGrafica.siguiente;
            }
        }
        private void graphLinkRowNode(string title, int level)
        {
            CabeceraNode filaGrafica = row.ini;
            while (filaGrafica != null)
            {
                MatrizNode nodoActualGrafica = filaGrafica.accesoBarco;
                fi = "F" + filaGrafica.indice.ToString();

                while (nodoActualGrafica != null)
                {
                    MatrizNode nodoAux = findLevel(nodoActualGrafica, level);
                    if (nodoAux != null)
                    {
                        nodo = "nd" + nodoAux.coor_y.ToString() + nodoAux.coor_x.ToString() + nodoAux.units.level.ToString();//Identificador para nodo                        
                        graphMatriz += fi + " -> " + nodo + ";\n\t";
                        graphMatriz += nodo + " -> " + fi + ";\n\t";
                        break;
                    }
                    nodoActualGrafica = nodoActualGrafica.right;
                }
                filaGrafica = filaGrafica.siguiente;
            }
        }
        private void graphLinkColumn(string title, int level)
        {
            CabeceraNode columnaGrafica = column.ini;
            graphMatriz += "MATRIZ";

            while (columnaGrafica != null)
            {
                MatrizNode nodoActual = columnaGrafica.accesoBarco;
                col = "C" + columnaGrafica.indice.ToString();
                while (nodoActual != null)
                {
                    MatrizNode nodoAux = findLevel(nodoActual, level);
                    if (nodoAux != null)
                    {
                        graphMatriz += " -> " + col;
                        //graphMatriz += "";
                        break;
                    }
                    nodoActual = nodoActual.down;
                }
                columnaGrafica = columnaGrafica.siguiente;
            }
            graphMatriz += ";\n\t";
        }
        private void graphLinkRow(string title, int level)
        {
            CabeceraNode filaGrafica = row.ini;
            graphMatriz += "MATRIZ";

            while (filaGrafica != null)
            {
                MatrizNode nodoActual = filaGrafica.accesoBarco;
                fi = "F" + filaGrafica.indice.ToString();
                while (nodoActual != null)
                {
                    MatrizNode nodoAux = findLevel(nodoActual, level);
                    if (nodoAux != null)
                    {
                        graphMatriz += " -> " + fi;
                        break;
                    }
                    nodoActual = nodoActual.right;
                }
                filaGrafica = filaGrafica.siguiente;
            }
            graphMatriz += ";\n\t";
        }
        private void sentRank(string title, int level)
        {
            CabeceraNode nodoEncabezadoAux = column.ini;
            graphMatriz += "{ rank=min; MATRIZ; ";
            while (nodoEncabezadoAux != null)
            {
                MatrizNode nodoActual = nodoEncabezadoAux.accesoBarco;
                col = "C" + nodoEncabezadoAux.indice.ToString();

                while (nodoActual != null)
                {
                    MatrizNode nodoAux = findLevel(nodoActual, level);
                    if (nodoAux != null)
                    {
                        graphMatriz += col + "; ";
                        break;
                    }
                    nodoActual = nodoActual.down;
                }
                nodoEncabezadoAux = nodoEncabezadoAux.siguiente;
            }
            graphMatriz += "};\n\t";

            //Filas
            nodoEncabezadoAux = row.ini;
            while (nodoEncabezadoAux != null)
            {
                MatrizNode nodoActual = nodoEncabezadoAux.accesoBarco;
                bool esFila = false;
                fi = "F" + nodoEncabezadoAux.indice.ToString();
                graphMatriz += "{ rank=same; " + fi + "; ";
                fi = "";

                while (nodoActual != null)
                {
                    MatrizNode nodoAux = findLevel(nodoActual, level);
                    if (nodoAux != null)
                    {
                        esFila = true;
                        nodo = "nd" + nodoAux.coor_y.ToString() + nodoAux.coor_x.ToString() + nodoAux.units.level.ToString();
                        graphMatriz += nodo + "; ";
                    }
                    nodoActual = nodoActual.right;
                }
                if (esFila)
                {
                    graphMatriz += "};\n\t";
                    esFila = false;
                }
                nodoEncabezadoAux = nodoEncabezadoAux.siguiente;
            }
        }
    }
}